﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DotNetXtensions.NetFX")]
[assembly: AssemblyProduct("DotNetXtensions.NetFX")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: ComVisible(false)]
// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("d90fc109-6c8b-47eb-ba29-3dffc336aeae")]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
