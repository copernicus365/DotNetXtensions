﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("DotNetXtensions.Json.NetFX")]
[assembly: AssemblyProduct("DotNetXtensions.Json.NetFX")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: ComVisible(false)]
[assembly: AssemblyVersion("1.1.0.0")]
[assembly: AssemblyFileVersion("1.1.0.0")]
